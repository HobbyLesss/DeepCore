# Deep Core
A standalone Godot 4.6.3 / GDScript third-person mining prototype. No external asset or package dependencies.

## Play
Import project.godot in Godot 4.6.3 and press F6 on scenes/main.tscn (or F5).
Choose Play / Continue. Mine the ground, fill your 20-unit backpack, return to the orange terminal, sell, and buy mining-power upgrades. R always returns you safely to the surface.

WASD move; mouse look; V switch first-person / third-person; Space jump; Shift sprint; hold left mouse mine; Tab inventory; Escape pause; E sell within four metres of terminal; U buy +10 damage/s (starts at 30 credits, scales with level); B buy +10 cargo capacity (starts at 40 credits); R recover; F5 save. Quit, selling, upgrades, and a 60-second active-play autosave also save. Saves live in user://deep_core.json with a backup file. Remove both files to reset.

## Architecture
- scenes/main.tscn and scripts/game.gd: scene composition, outpost, menus, HUD and actions.
- player.gd: accelerated CharacterBody3D movement, spring-arm camera, articulated GLB character.
- miner_model.gd and assets/models/miner.glb: original contoured miner with articulated limbs, hardhat, respirator, harness and pickaxe. tests/export_model.gd regenerates the GLB from its procedural source.
- landscape.gd: non-destructible distant terrain surrounding the mine.
- assets/shaders/rock.gdshader: world-space grain, strata, roughness and fine normal relief.
- generation.gd: deterministic seed and clustered geological resources.
- terrain.gd: chunk lookup, persistent edits and localized rebuilds.
- chunk.gd: 16³ packed-byte chunks, marching-tetrahedra isosurfaces and matching chunk collision.
- blocks.gd: resource colors, hardness and values.
- mining.gd: camera ray, 3 m reach, surface sample lookup, strike-based damage, surface reticle, rock chips and rewards.
- inventory.gd: independent capacity, cargo valuation, sales and scaling tool/backpack upgrades.
- expedition_hud.gd: styled status cards, first-expedition goals, terminal pricing and notifications.
- sound.gd: generated impact and reward sounds; no external audio assets.
- save_store.gd: versioned temporary-file save, rename and backup fallback.

The finite mine is 32 × 32 × 48 metres (12 chunks), with negative-coordinate support. Permanent retaining walls and a bottom floor enclose it. Generation has three depth bands; the last is truncated at 48 m. No individual voxel nodes. Removal rebuilds only chunks whose isosurface cells depend on the edited sample, including diagonal neighbors at corners. HUD exposes FPS and rebuild count.

## Validate
godot --headless --editor --path . --quit
godot --headless --path . --script tests/smoke.gd

IMPORTANT: the smoke test deletes saves in its user-data directory. Always use isolated XDG_DATA_HOME on Linux:
XDG_DATA_HOME=/workspace/.deepcore/test-data XDG_CONFIG_HOME=/workspace/.deepcore/config XDG_CACHE_HOME=/workspace/.deepcore/cache godot --headless --path . --script tests/smoke.gd

Tests exercise real terrain generation/collision, player motion and jump, ray targeting, mining progress and collection, capacity, sales, negative coordinates, boundary rebuild counts, duplicate prevention and save/restore. Headless validation does not establish graphical quality or Windows runtime compatibility.

Cloud editor/run commands should set XDG_DATA_HOME=/workspace/.deepcore/data, XDG_CONFIG_HOME=/workspace/.deepcore/config and XDG_CACHE_HOME=/workspace/.deepcore/cache because default home paths are read-only.

## Windows export
Install matching Godot 4.6.3 export templates using Editor → Manage Export Templates. Use Project → Export → Windows Desktop, or:
godot --headless --path . --export-release "Windows Desktop" Builds/Windows/DeepCore.exe

## Current limitations / next milestone
The miner is an original procedural GLB with articulated rigid parts, not a scanned or professionally sculpted/skinned character. Terrain is a continuous, faceted isosurface with procedural rock shading, rather than exposed voxel cubes. Mining applies damage once per 0.6-second strike with sound, small rock chips and subtle camera impulse. The world includes distant landscape meshes, sun shadows and atmospheric fog. Camera sensitivity is exposed in player.gd, without a settings screen. Linux offscreen OpenGL rendering was inspected at 1280×720; Windows gameplay, audio quality and subjective camera/tool feel still need interactive playtesting. Chunk meshing and collision rebuilds are synchronous; profile before expanding to streaming. Saves have versioning and backup recovery but no comprehensive schema validation. A four-step expedition guides mining, selling, upgrading and reaching Iron Ridge; no authored campaign or ending yet.

Next milestone: graphical playtesting, richer ore materials, authored exploration spaces, robust save migration, and profiling before threaded chunk streaming.

## Graphics pass (v0.3)
The editable GLB is in assets/models/miner.glb and is used by the player at runtime.
It is original project geometry; no third-party model license is required.
The terrain continues to use compact samples for persistence, but its displayed and
collision surfaces are triangle meshes interpolated between solid and empty samples.
Existing excavation saves remain readable, although the shape around their edges changes.
The current surface resolution is still one metre. This is a more natural-looking
prototype foundation, not photorealistic terrain or production character art.

Offscreen capture: run tests/visual.gd with an X11 display and isolated
XDG_DATA_HOME; it writes /workspace/DeepCore-graphics.png. This is a diagnostic
camera pose and excavated scene, not a replacement for playing the game.


## Camera modes (v0.4)
Press V during gameplay to switch between third-person and first-person.
Both use the same movement, targeting, inventory and mining systems.
First person places the camera at eye level and displays an animated arm and
pickaxe; third person uses the full character and collision-aware spring arm.
Your selected view is included in expedition saves. Old saves default to third person.
The toggle is disabled while menus are open.
